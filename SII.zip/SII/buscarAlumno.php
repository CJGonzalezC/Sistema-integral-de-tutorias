<?php
require 'conexion.php';
session_start();
//validar que se haya creado una session si no redirijir a index.php
if(!isset($_SESSION['ClaveMaestro']))
{
        header("Location:index.php");
}
else
{
    //que el usuario sea de tipo administrador si no redirijir a welcome
        if(!($_SESSION['Tipo']=='A'))
        {
             header("Location:welcome.php");   
        }
        
}
$Clave = $_GET['term'];
 
$consulta = "SELECT NoControl FROM alumnos WHERE NoControl LIKE '%$Clave%'";
 
$result = $conexion->query($consulta);
 
if($result->num_rows > 0){
    while($fila = $result->fetch_array()){
        $numeros[] = $fila['NoControl'];
    }
echo json_encode($numeros);
}

?>