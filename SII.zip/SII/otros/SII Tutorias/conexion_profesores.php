<?php
	error_reporting(E_ALL ^ E_DEPRECATED);
	$username=$_POST['usuario']; 
	$password=$_POST['password'];

define('DB_SERVER','localhost'); 
define('DB_NAME','tutoriasBD'); 
define('DB_USER','root'); 
define('DB_PASS',''); 

$con = mysql_connect(DB_SERVER,DB_USER,DB_PASS); 
mysql_select_db(DB_NAME,$con); 

if($con)
{
	echo "conectado2";
}
else
{
	echo "FALLIDO";
}

	session_start();
	
	$result = mysql_query("select * from usuarios where Usuario = '$username'
	and Password = '$password'") or die("Fail to query database".mysql_error());
	$row = mysql_fetch_array($result);
	if($row['Usuario']==$username && $row['Password']==$password){
		$_SESSION['iusuario']= $row['Usuario'];
		//header("Location:Sesion_estudiantes.php");
				//header("Location:FormularioProfesores.php");
				header("Location:menu.php");
	}
	else {
		echo "Failed to login!";
	}
?>
	