<?php

$conexion=  new mysqli("localhost","root","","basetuto");

$tarjeta=$_POST['notarjeta']; 
	$nfc=$_POST['rfc'];
    $nombre=$_POST['nombre'];
    $titulo=$_POST['titulo'];
    $celular=$_POST['celular'];
    $email=$_POST['email'];
    
    
   // $result = mysql_query("insert into profesores(no_tarjeta,rfc,nombre,titulo,celular,email) values('$tarjeta','$nfc','$nombre','$titulo','$celular','$email'")
	//$row = mysql_fetch_array($result);
    $resultado="insert into profesores(no_tarjeta,rfc,nombre,titulo,celular,email) values('$tarjeta','$nfc','$nombre','$titulo','$celular','$email')";
	$t=$conexion->query($resultado);
if($resultado)
{
    
    echo "ingresado corectamente";
}
else{
    echo "no se pudo";
}
?>