<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
     
     <link rel="stylesheet" href="css/layer.css">
     
     <script src="js/jquery/jquery-1.11.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
     <div class="container" style="background: #00f;">
     
           <h1>
            Sistema Integral de Información
            <h2>
                  Instituto Tecnológico de Delicias
            </h2>


            <small>SII TUTORIAS</small>
           </h1>
        </div>
</head>

<body>
   
    <!--Utilizar bootstrap-->
    <!--sistema de rejilla(grid)-->
    <header>
      
 <div class="container-fluid">
        <nav class="navbar navbar-default">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed"
                    data-toggle="collapse"
                    data-target="#bs-activacion"
                    aria-expanded="false">
                <span class="sr-only">menu</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
      
      </div>
     <a href="index1.html" class="navbar-brand">
                <i class="fa fa-home 2x fa-spin"></i></a>
 
         <!-- recopile los viculos de navegacin, formularios y otros contenidos para activar-->
        <div class="collapse navbar-collapse" id="bs-activacion">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="students.php">Estudiantes<span class="sr-only">(actual)</span></a>
                </li>
                <li>
                    <a href="Profesores.php">Profesores</a>
                </li>
            </ul>
        </div>
      </div>
  </nav>
    </header>
    
    
    <section class="container">
    <div class="container">
      <div id="contenido">
              <div class="row">
            
                        <div class="col-sm-offset-3 col-sm-6">
                          <div class="panel panel-primary"><!--success, primary o default-->
                              <div class="panel-heading">
                                        <h3 class="panel-title">
                                            Login<i class="fa fa-key fa-2x pull-right"></i><br><small>
                                                Introduzca usuario y password
                                            </small>
                                        </h3>
                              </div>
                              
                              <div class="panel-body">
                                <form action="inistudents.php" class="form-horizontal" method="POST">
                                    
                                    <div class="form-group">
                                        <label for="usuario" class="sr-only">
                                            Usuario:
                                        </label>
                                        <input type="text" id="usuario" name="usuario" class="form-control" placeholder="usuario" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="password" class="sr-only">
                                            Password:
                                        </label>
                                        <input type="password" id="password" name="password" class="form-control" placeholder="password"> 
                                    </div>
                                    <button class="btn btn-primary btn-lg">
                                        Iniciar
                                    </button>
                                    
                                </form>
                              </div>
                              
                              <div class="panel-footer">
                                    <h6>Solo para usuarios registrados</h6>
                              </div>
                          </div>
                        </div>
                  </div>
            </div>
      </div>
    </section>
    
    <aside>
        
    </aside>
    <footer>
        
    </footer>
    
</body>

</html>