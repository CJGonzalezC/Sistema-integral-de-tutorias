<?php
	error_reporting(E_ALL ^ E_DEPRECATED);
	$username=$_POST['usuario']; 
	$password=$_POST['password'];

	//$username = stripcslashes($username);
	//$password = stripcslashes($password);
	//$username = mysql_real_escape_string($username);
	//$password = mysql_real_escape_string($password);

	//mysql_connect("localhost","root","zero");
	//mysql_select_db("studentsusers");
// datos para la coneccion a mysql 
define('DB_SERVER','localhost'); 
define('DB_NAME','basetuto'); 
define('DB_USER','root'); 
define('DB_PASS',''); 

$con = mysql_connect(DB_SERVER,DB_USER,DB_PASS); 
mysql_select_db(DB_NAME,$con); 

	$result = mysql_query("select * from alumnos where user = '$username'
	and password = '$password'") or die("Fail to query database".mysql_error());
	$row = mysql_fetch_array($result);
	if($row['user']==$username && $row['password']==$password){
		//echo "Login success!!! Welcome student ".$row['user'];
		header("Location:pruebas.html");
		
	}
	else {
		echo "Failed to login!";
	}
?>
