<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <?php
    session_start();
    if(isset($_SESSION['iusuario'])){
        echo "Bienvenido ".$_SESSION['iusuario'];
    }
    else{
        echo "fallo sesion";
    }
    ?>
    <form action="formulariop.php" method="post">  <!--metodos get, post, put-->
        
    <fieldset>
        <legend>Datos</legend>
        
    <!--etiquetas para los fomulario -->
    <label for="notarjeta">No Tarjeta:</label>&nbsp;&nbsp;
    <input type="text"  name="notarjeta" id="notarjeta"  maxlength="60" size="30"
           required="required">
    <br>
    <label for="rfc">RFC:</label>&nbsp;&nbsp;
    <input type="text"  name="rfc" id="rfc"  maxlength="60" size="30"
           required="required">
    <br>
    
    <label for="nombre">Nombre:</label>&nbsp;&nbsp;
    <input type="text"  name="nombre" id="nombre"  maxlength="60" size="30"
           required="required">
    <br>
    <label for="titulo">titulo:</label>&nbsp;&nbsp;
    <input type="text"  name="titulo" id="titulo"  maxlength="13" size="30">
    <br>
    <label for="celular">celular:</label>&nbsp;&nbsp;
    <input type="text"  name="celular" id="celular"  maxlength="13" size="30">
    <br>
    
    <br>
    <label for="email">email:</label>
    <input type="email"  name="email" id="email">
    <br>
    
    <button type="submit">Enviar</button>
    </fieldset>  

    </form>
    
</body>

</html>    